<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PET CARE MANAGEMENT SYSTEM</title>
<meta name="keywords" content="free design template, download web templates, Pinky Website, XHTML, CSS" />
<meta name="description" content="Pinky Template - Free CSS Template, Free XHTML CSS Design Layout" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
<body>
	<div id="templatemo_top_bg">
    	<div class="templatemo_container">
        <!--  Free CSS Template is provided by www.TemplateMo.com  -->
        	<div id="templatemo_header_top">
	        	<div id="templatemo_logo">
                	<div id="templatemo_title">
                    	<!--<span class="white">
                        	PET CARE MANAGEMENT
                        </span>
                        <span class="pink">
                        	 SYSTEM
                        </span>-->
                        <h3 style="color:white">PET CARE MANAGEMENT SYSTEM</h3>
                        
                    </div>
    	        </div>
                <div id="templatemo_search">
	                <form method="post">
						<label>Search:</label>
						<input name="search" value="Search ..." type="text" onfocus="clearText(this)" onblur="clearText(this)" class="textbox"/>
						<input type="submit" name="Search" value="GO" class="button"/>
               		</form>
                </div>
			</div><!-- End Of Header Top-->
            <div class="cleaner"></div>
            <div id="templatemo_header_bottom">
            	<div id="templatemo_menu_section">
					<ul>
		                <li><a href="#" class="current">Pet Details</a></li>
        		        <li><a href="">Accept/Reject</a></li>
                        <li><a href="payment.php">Payment</a></li>
		                <li><a href="outstand.php">Balance</a></li>      
                        <li><a href="view_return.php">Pet Status</a></li>
		                
                        <a href="logout.php" style="color:white;top:117px;position:absolute"><b>Logout</b></a>     
	              </ul>
				</div>
            
            <div class="cleaner"></div>
            	<div id="templatemo_header_textarea">
                	<h1><a href="#">Pets</a></h1>
                    <p>Deciding to become a pet owner requires considered thought and planning - all potential pet owners need to be sure they are really ready to take on the responsibility of owning a pet before going ahead and making a choice of breed of pet. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Children</a></h1>
                    <p>Dogs and children have a very special bond. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Interaction</a></h1>
                    <p>Dogs can provide children with companionship. </p>                             
                </div>
            </div><!-- End Of Header Bottom-->
            <div class="cleaner_with_height"></div>
        </div><!-- End Of Container -->

    </div><!-- End Of Top Bg -->

	<div id="templatemo_middle_bg">
    	<div class="templatemo_container">
        	<div id="templatemo_three_col">
            
            	<div>
			<form name='f' method="post" enctype="multipart/form-data">
				<table><tr><td>Select Pet Qrcode
					<td><input type="file" name="fi">
					<tr><td><input type="submit" name="sub">
				</table>
			</form>

			
                
                	<div>
                    	
                        <?php	
			include './db.php';
			if(isset($_POST["sub"]))
			{	  
			$fname="uploads////".$_FILES['fi']['name'];			
			$result = mysqli_query($linkid, "select cdate,oname,ptype,ndays,fdate,tdate from pet_det where status='-' and qrpath='$fname'");
    echo "<table style='float:none;margin:20px auto;' border=4><thead><tr><th colspan='7'>  VIEW PET DETAILS<tr>";
    echo "<tr><th>Request Date<th>Owner Name<th>Pet Type<th>No. of days<th>From Date<th>To Date<th>Status<tbody>";
    while($row= mysqli_fetch_row($result))
	 {
	echo "<tr>";
	foreach($row as $r)
	    echo "<td>$r";
	echo "<td><a href='response.php?p=$row[0]&q=$row[1]'>Accept/Reject</a>";		
    }
	}
	
    echo "</tbody></table>";
?>
                        
					  
                    </div>      
                    
                </div><!-- End Of Column -->
                
                
		
            </div><!-- End Of Column -->
             <div class="cleaner"></div>
            </div><!-- End Of Three Col -->
            <div class="cleaner"></div>
        </div><!-- End Of Container -->
    </div><!-- End Of middle Bg -->

    <div id="templatemo_footer_bg">
    	
    </div><!-- End Of middle footer bg -->
    <!--  Free CSS Templates by TemplateMo.com  -->
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>

