<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PET CARE MANAGEMENT SYSTEM</title>
<meta name="keywords" content="free design template, download web templates, Pinky Website, XHTML, CSS" />
<meta name="description" content="Pinky Template - Free CSS Template, Free XHTML CSS Design Layout" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
<body>
	<div id="templatemo_top_bg">
    	<div class="templatemo_container">
        <!--  Free CSS Template is provided by www.TemplateMo.com  -->
        	<div id="templatemo_header_top">
	        	<div id="templatemo_logo">
                	<div id="templatemo_title">
                    	<!--<span class="white">
                        	PET CARE MANAGEMENT
                        </span>
                        <span class="pink">
                        	 SYSTEM
                        </span>-->
                        <h3 style="color:white">PET CARE MANAGEMENT SYSTEM</h3>
                        
                    </div>
    	        </div>
                <div id="templatemo_search">
	                <form method="post">
						<label>Search:</label>
						<input name="search" value="Search ..." type="text" onfocus="clearText(this)" onblur="clearText(this)" class="textbox"/>
						<input type="submit" name="Search" value="GO" class="button"/>
               		</form>
                </div>
			</div><!-- End Of Header Top-->
            <div class="cleaner"></div>
            <div id="templatemo_header_bottom">
            	<div id="templatemo_menu_section">
					<ul>
		                <li><a href="pet_det.php" class="current">Pet Entry</a></li>
        		        <li><a href="req_status.php">Req. Status</a></li>
		                <li><a href="#">Food</a></li>
                         <li><a href="return_status.php">Return</a></li>            
                        <li><a href="">Payment</a></li>
		              
                         <a href="logout.php" style="color:white;top:117px;position:absolute"><b>Logout</b></a> 
	              </ul>    
	              </ul>
				</div>
            
            <div class="cleaner"></div>
            	<div id="templatemo_header_textarea">
                	<h1><a href="#">Pets</a></h1>
                    <p>Deciding to become a pet owner requires considered thought and planning - all potential pet owners need to be sure they are really ready to take on the responsibility of owning a pet before going ahead and making a choice of breed of pet. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Children</a></h1>
                    <p>Dogs and children have a very special bond. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Interaction</a></h1>
                    <p>Dogs can provide children with companionship. </p>                             
                </div>
            </div><!-- End Of Header Bottom-->
            <div class="cleaner_with_height"></div>
        </div><!-- End Of Container -->

    </div><!-- End Of Top Bg -->

	<div id="templatemo_middle_bg">
    	<div class="templatemo_container">
        	<div id="templatemo_three_col">
            
            	<div>
                
                	<div>
                    	<?php	
			include("./db.php");	
			session_start();
			$un=$_SESSION["owner"];
			$tid=$_REQUEST["t"];
$re=mysqli_query($linkid,"select * from outstand where tid=$tid");
$rc=mysqli_fetch_array($re);
echo "<table align=center>";
echo "<tr><td colspan=2 align=center>Welcome $un</td></tr>";
echo "<tr><td>Your Outstanding Amount is Rs.</td><td>$rc[3]</td></tr>";
echo "</table>";
if(!isset($_POST['submit']))
 {
?>
<form name="f" method="post">
<table align="center">
<tr>
<th colspan="2">Payment Form</th>
</tr>
<tr>
<td>Enter Your Bank Name</td>
<td><input type="text" name="t1"></td>
</tr>
<tr>
<td>Enter Your Card Type</td>
<td><input type="text" name="t2"></td>
</tr>
<tr>
<td>Enter Your Card Number</td>
<td><input type="text" name="t3"></td>
</tr>
<tr>
<td>Transaction Date</td>
<td><input type="date" name="t4" value=<?php
echo date("Y-m-d",time());
?>></td>
</tr>
<tr>
<td>Amount Payable</td>
<td><input type="text" name="t5"></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Pay It">&nbsp;&nbsp;<a href="logout.php">LogOut</a></td>
</tr>
</table>
</form>
<?php
}
else
 {
	$uname=$un;
	$bank=$_POST['t1'];
	$ctype = $_POST['t2'];
	$cno = $_POST['t3'];
	$tdate = $_POST['t4'];
	$amt  = $_POST['t5'];
	mysqli_query($linkid,"insert into receipt values ($tid,'$uname','$bank','$ctype','$cno','$tdate',$amt)");
	mysqli_query($linkid,"update outstand set amt=amt-$amt where tid=$tid");
	
	$q=mysqli_query($linkid,"select rdate,ptype from return_det where tid=$tid");
	
	$r=mysqli_fetch_row($q);
	
	$rdate=$r[0];
	$ptype=$r[1];
	
	$q=mysqli_query($linkid,"select amt from outstand where tid=$tid");
	$r3=mysqli_fetch_row($q);
	
	$amt1=$r3[0];
	
	echo $amt;
	
	if($amt1==0)
	{
		$q=mysqli_query($linkid,"update pet_det set status='return' where cdate='$rdate' and oname='$un' and ptype='$ptype'");
	}
	header('Location:pay.php');
	echo "<div align='center'>Paid Successfully...!<br><a href='pay.php'>Back</a></div>";  
	//header('Location:payment.php');
}

?>
					  
                    </div>      
                    
                </div><!-- End Of Column -->
                
                
		
            </div><!-- End Of Column -->
             <div class="cleaner"></div>
            </div><!-- End Of Three Col -->
            <div class="cleaner"></div>
        </div><!-- End Of Container -->
    </div><!-- End Of middle Bg -->

    <div id="templatemo_footer_bg">
    	
    </div><!-- End Of middle footer bg -->
    <!--  Free CSS Templates by TemplateMo.com  -->
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
<script type="text/javascript">
function process()
{
		if(f.ptype.value=="Dog")
			f.pday.value=1000;
		else if(f.ptype.value=="Cat")
			f.pday.value=500;
		else if(f.ptype.value=="Others")
			f.pday.value=700;		
}
</script>